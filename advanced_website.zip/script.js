function scrollToSection() {
  document.getElementById("info").scrollIntoView({ behavior: "smooth" });
}
